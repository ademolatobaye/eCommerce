<?php

// DATABASE USERNAME, PASSWORD, DATABASE NAME
$conn = new mysqli("localhost", "ecommerce_user", "ecommerce@2026", "ecommerce_db");

if(mysqli_connect_errno()){
    printf("connect failed: %s\n", mysqli_connect_error());
    exit();
}

?>